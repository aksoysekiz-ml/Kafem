﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KAFEM0.personel_urun_takip
{
    public partial class u_takip : Form
    {
        public u_takip()
        {
            InitializeComponent();
        }
    }
}
